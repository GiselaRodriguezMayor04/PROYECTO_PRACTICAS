from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import check_password_hash
from conexion import dbConnection
import time

# Tiempos de activación
door_pin = 17
door_time = 5
luz_principal_time = 5
oficina_ventana_time = 5
oficina_escalera_time = 5

app = Flask(__name__)
app.secret_key = "tu_clave_secreta"

db = dbConnection()

if db is None:
    print("Error al conectar con la BD")
    exit()

usuarios = db['USUARIOS']

@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('index.html', door_time=door_time, 
                           luz_principal_time=luz_principal_time, 
                           oficina_ventana_time=oficina_ventana_time,
                           oficina_escalera_time=oficina_escalera_time)

@app.route('/activate/<device>')
def activate_device(device):
    global door_time, luz_principal_time, oficina_ventana_time, oficina_escalera_time
    
    # Activación de la puerta
    if device == 'door':
        print(f"Puerta activada durante {door_time} segundos")
        time.sleep(door_time)
        return jsonify({'status': 'ok'})
    
    # Activación de la luz principal
    elif device == 'luz_principal':
        print(f"Luz Principal activada durante {luz_principal_time} segundos")
        time.sleep(luz_principal_time)
        return jsonify({'status': 'ok'})
    
    # Activación de la oficina ventana
    elif device == 'oficina_ventana':
        print(f"Oficina Ventana activada durante {oficina_ventana_time} segundos")
        time.sleep(oficina_ventana_time)
        return jsonify({'status': 'ok'})
    
    # Activación de la oficina escalera
    elif device == 'oficina_escalera':
        print(f"Oficina Escalera activada durante {oficina_escalera_time} segundos")
        time.sleep(oficina_escalera_time)
        return jsonify({'status': 'ok'})
    
    print(f"Dispositivo {device} activado")
    return jsonify({'status': 'ok'})

@app.route('/config_puerta', methods=['GET', 'POST'])
def config_puerta():
    global door_time
    if request.method == 'POST':
        door_time = int(request.form['door_time'])
        return redirect(url_for('index'))
    return render_template('config_puerta.html', door_time=door_time)

@app.route('/config_luz/<device>', methods=['GET', 'POST'])
def config_luz(device):
    global luz_principal_time, oficina_ventana_time, oficina_escalera_time
    
    # Determinamos cuál dispositivo se está configurando
    if device == 'luz_principal':
        current_time = luz_principal_time
    elif device == 'oficina_ventana':
        current_time = oficina_ventana_time
    elif device == 'oficina_escalera':
        current_time = oficina_escalera_time
    else:
        return redirect(url_for('index'))
    
    # Guardamos el nuevo tiempo si es un POST
    if request.method == 'POST':
        new_time = int(request.form['door_time'])
        if device == 'luz_principal':
            luz_principal_time = new_time
        elif device == 'oficina_ventana':
            oficina_ventana_time = new_time
        elif device == 'oficina_escalera':
            oficina_escalera_time = new_time
        return redirect(url_for('index'))
    
    return render_template('config_luz.html', door_time=current_time, device=device)

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = usuarios.find_one({'username': username})

        if user and check_password_hash(user['password'], password):
            session['username'] = username
            return redirect(url_for('index'))
        else:
            error = "Usuario o contraseña incorrectos."

    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
