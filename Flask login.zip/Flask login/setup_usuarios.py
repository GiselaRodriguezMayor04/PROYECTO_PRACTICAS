from werkzeug.security import generate_password_hash
from database import dbConnection

# Conectar a la base de datos
db = dbConnection()

# Colección de usuarios
usuarios = db['USUARIOS']

# Crear un usuario administrador
usuarios.insert_one({
    'username': 'admin',  # Nombre de usuario
    'password': generate_password_hash('admin2025'),  # Contraseña encriptada
    'role': 'admin'  # Rol del usuario (admin o user)
})

# Crear un usuario normal
usuarios.insert_one({
    'username': 'user',
    'password': generate_password_hash('2025'),
    'role': 'user'
})

print("Usuarios creados correctamente")
