from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import database as dbase
from Cliente import Cliente
from bson.objectid import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash

db = dbase.dbConnection()

app = Flask(__name__)
app.secret_key = 'secret_key'

# Rutas de la aplicación


@app.route('/')
def home():
    if 'user' in session:
        clientes = db['CLIENTES']
        clientesReceived = clientes.find()
        return render_template('index.html', clientes=clientesReceived)
    else:
        return redirect(url_for('login'))

# Página de login


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Conectar con la base de datos de usuarios
        usuarios = db['USUARIOS']
        user = usuarios.find_one({'username': username})

        if user and check_password_hash(user['password'], password):
            # Guardar el nombre de usuario en la sesión
            session['user'] = username
            session['role'] = user['role']  # Guardar el rol en la sesión
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error="Credenciales incorrectas")

    return render_template('login.html')

# Método POST - Agregar Cliente


@app.route('/clientes', methods=['POST'])
def addCliente():
    clientes = db['CLIENTES']
    nombre = request.form['nombre']
    n_pantallas = request.form['n_pantallas']
    players_activos = request.form['players_activos']

    if not n_pantallas.isdigit() or not players_activos.isdigit():
        return notFound()

    n_pantallas = int(n_pantallas)
    players_activos = int(players_activos)

    if nombre and n_pantallas >= 0 and players_activos >= 0:
        cliente = Cliente(nombre, n_pantallas, players_activos)
        clientes.insert_one(cliente.toDBCollection())
        return redirect(url_for('home'))
    else:
        return notFound()

# Método DELETE - Eliminar Cliente


@app.route('/delete/<string:nombre_cliente>')
def delete(nombre_cliente):
    # Solo los admin pueden eliminar
    if 'user' not in session or session['role'] != 'admin':
        return redirect(url_for('home'))

    clientes = db['CLIENTES']
    clientes.delete_one({'nombre': nombre_cliente})
    return redirect(url_for('home'))

# Método EDIT - Editar Cliente


@app.route('/edit/<string:nombre_cliente>', methods=['POST'])
def edit(nombre_cliente):
    # Solo los admin pueden editar
    if 'user' not in session or session['role'] != 'admin':
        return redirect(url_for('home'))

    clientes = db['CLIENTES']
    nombre = request.form['nombre']
    n_pantallas = request.form['n_pantallas']
    players_activos = request.form['players_activos']

    if not n_pantallas.isdigit() or not players_activos.isdigit():
        return notFound()

    n_pantallas = int(n_pantallas)
    players_activos = int(players_activos)

    if nombre and n_pantallas >= 0 and players_activos >= 0:
        clientes.update_one({'nombre': nombre_cliente}, {
            '$set': {'nombre': nombre, 'n_pantallas': n_pantallas, 'players_activos': players_activos}})
        return redirect(url_for('home'))
    else:
        return notFound()

# Método - Buscar por ID


@app.route('/buscar', methods=['POST'])
def buscar_por_id():
    clientes = db['CLIENTES']
    cliente_id = request.form['cliente_id']

    try:
        cliente_obj_id = ObjectId(cliente_id)
        # Buscar el cliente por el ObjectId
        cliente = clientes.find_one({'_id': cliente_obj_id})

        if cliente:
            return render_template('buscar.html', cliente=cliente)
        else:
            return notFound()

    except Exception as e:
        return notFound()

# Método logout


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.errorhandler(404)
def notFound(error=None):
    message = {
        'message': 'No encontrado ' + request.url,
        'status': '404 Not Found'
    }
    response = jsonify(message)
    response.status_code = 404
    return response


if __name__ == '__main__':
    app.run(debug=True, port=4000)
