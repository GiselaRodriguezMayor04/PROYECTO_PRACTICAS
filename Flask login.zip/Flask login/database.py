from pymongo import MongoClient
import certifi

MONGO_URI = 'mongodb+srv://user:2025@cluster0.vd5s2.mongodb.net/'
ca = certifi.where()


def dbConnection():
    try:
        client = MongoClient(MONGO_URI, tlsCAFile=ca)
        db = client["DATOS_INFO"]
    except ConnectionError:
        print('Error de conexión con la BDD')
    return db
