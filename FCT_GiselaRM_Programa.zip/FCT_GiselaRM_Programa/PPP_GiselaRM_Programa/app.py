from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import conexion_bd as dbase
from bson.objectid import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os

db = dbase.dbConnection()

app = Flask(__name__)
app.secret_key = 'secret_key'

# Configuración para los archivos subidos
UPLOAD_FOLDER = r'\\MONGOSERVER\Media'
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov', 'avi'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Función para verificar si el archivo tiene una extensión permitida
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# HOME - TE MANDA AL INDEX SI HAS INTRODUCIDO EL LOGIN CORRECTAMENTE
@app.route('/')
def home():
    if 'user' in session:
        clientes = db['CLIENTES']
        clientesReceived = clientes.find()
        return render_template('index.html', clientes=clientesReceived)
    else:
        return redirect(url_for('login'))

# Ruta para el formulario de cliente (cuestionario)
@app.route('/cuestionario', methods=['GET', 'POST'])
def cuestionario():
    if request.method == 'POST':
        # Procesa los datos del cuestionario aquí
        nombre = request.form['nombre']
        n_pantallas = request.form['n_pantallas']
        players_activos = request.form['players_activos']

        if not nombre or not n_pantallas or not players_activos:
            flash('Todos los campos son obligatorios.', 'error')
            return render_template('cuestionario.html')

        # Si todo es correcto, guardamos el cliente en la base de datos
        clientes = db['CLIENTES']
        cliente = {
            'nombre': nombre,
            'n_pantallas': n_pantallas,
            'players_activos': players_activos
        }
        clientes.insert_one(cliente)
        flash('Cliente guardado correctamente!', 'success')

        return redirect(url_for('home'))  # Redirige al index después de guardar el cliente

    return render_template('cuestionario.html')

# LOGIN - SE ENCARGA DE MIRAR SI ENTRA EL USUARIO CORRECTO Y SABER CUÁL ES, SI ES ADMIN, TIENE PRIVILEGIOS DE ADMINISTRADOR, SI NO, ES UN USUARIO NORMAL
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        usuarios = db['USUARIOS']
        user = usuarios.find_one({'username': username})

        if user and check_password_hash(user['password'], password):
            session['user'] = username
            session['role'] = user['role']
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error="Credenciales incorrectas")

    return render_template('login.html')

# Resto de las rutas y funciones de tu aplicación...

if __name__ == '__main__':
    app.run(debug=True, port=4000)
