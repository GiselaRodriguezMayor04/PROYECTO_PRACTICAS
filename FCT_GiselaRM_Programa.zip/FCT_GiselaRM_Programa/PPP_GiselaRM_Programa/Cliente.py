class Cliente:
    def __init__(self, nombre, n_pantallas, players_activos):
        self.nombre = nombre
        self.n_pantallas = n_pantallas
        self.players_activos = players_activos

    def toDBCollection(self):
        return {
            'nombre': self.nombre,
            'n_pantallas': self.n_pantallas,
            'players_activos': self.players_activos
        }

    @staticmethod
    def fromDBCollection(data):
        return Cliente(
            nombre=data['nombre'],
            n_pantallas=data['n_pantallas'],
            players_activos=data['players_activos']
        )
