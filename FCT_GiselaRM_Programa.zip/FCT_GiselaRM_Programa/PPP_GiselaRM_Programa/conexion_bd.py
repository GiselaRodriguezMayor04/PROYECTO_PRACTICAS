# Conexión con la BD, tenemos el conector, el nombre y los mensajes de éxito o error
from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError
import certifi

MONGO_URI = 'mongodb://10.15.1.7:27017/'
ca = certifi.where()


def dbConnection():
    try:
        client = MongoClient(MONGO_URI)
        db = client["DTBS_FCT"]
        client.admin.command('ping')
        print("Conexión exitosa a la BD! :)")
        return db
    except ServerSelectionTimeoutError as e:
        print(f"Error al intentar conectarse a la BD: {e}")
        return None
