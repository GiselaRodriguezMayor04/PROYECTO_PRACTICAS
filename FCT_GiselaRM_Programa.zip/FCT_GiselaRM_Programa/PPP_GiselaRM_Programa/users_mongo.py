from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError
import certifi
from werkzeug.security import generate_password_hash

MONGO_URI = 'mongodb://10.15.1.7:27017/'
ca = certifi.where()

# Conexión a la base de datos
def dbConnection():
    try:
        client = MongoClient(MONGO_URI)
        db = client["DTBS_FCT"]
        client.admin.command('ping')  # Asegura que la conexión sea exitosa
        print("Conexión exitosa a la BD! :)")
        return db
    except ServerSelectionTimeoutError as e:
        print(f"Error al intentar conectarse a la BD: {e}")
        return None

# Conectar a la base de datos
db = dbConnection()

if db is None:
    print("No se pudo conectar con la base de datos. Vuelve a intentarlo más tarde.")
    exit()

# Obtener la colección de usuarios
usuarios = db['USUARIOS']

# Crear usuarios si no existen
if not usuarios.find_one({'username': 'admin'}):
    usuarios.insert_one({
        'username': 'admin',
        'password': generate_password_hash('admin2025'),
        'role': 'admin'
    })
    print("Usuario 'admin' creado correctamente!")

if not usuarios.find_one({'username': 'user'}):
    usuarios.insert_one({
        'username': 'user',
        'password': generate_password_hash('user2025'),
        'role': 'user'
    })
    print("Usuario 'user' creado correctamente!")
