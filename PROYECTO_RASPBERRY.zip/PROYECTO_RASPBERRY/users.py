from werkzeug.security import generate_password_hash
from conexion import dbConnection

db = dbConnection()

if db is None:
    print("No se pudo conectar con la base de datos. Vuelve a intentarlo más tarde.")
    exit()

usuarios = db['USUARIOS']

usuarios.insert_one({
    'username': 'NETTRONICA',
    'password': generate_password_hash('1234'),
    'role': 'admin'
})

print("Usuarios creados correctamente!")
