from werkzeug.security import generate_password_hash
from conexion import dbConnection

db = dbConnection()

if db is None:
    print("Error al conectar con la BD")
    exit()

usuarios = db['USUARIOS']

usuarios.insert_one({
    'username': 'NETTRONICA',
    'password': generate_password_hash('1234'),
    'role': 'admin'
})

print("Usuarios creados correctamente!")
