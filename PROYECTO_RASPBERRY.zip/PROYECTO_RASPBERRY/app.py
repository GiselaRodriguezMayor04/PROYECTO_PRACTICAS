from flask import Flask, render_template, request, redirect, url_for, session
from werkzeug.security import check_password_hash
from conexion import dbConnection
import time

door_pin = 17
door_time = 5

app = Flask(__name__)
app.secret_key = "tu_clave_secreta"  

db = dbConnection()

if db is None:
    print("No se pudo conectar con la base de datos. Vuelve a intentarlo más tarde.")
    exit()

usuarios = db['USUARIOS']

@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('index.html', door_time=door_time)

@app.route('/activate/<device>')
def activate_device(device):
    if device == 'door':
        time.sleep(door_time) 
        print(f"Puerta activada durante {door_time} segundos")
    return redirect(url_for('index'))

@app.route('/config_puerta', methods=['GET', 'POST'])
def config_puerta():
    global door_time
    if request.method == 'POST':
        door_time = int(request.form['door_time'])
        return redirect(url_for('index'))
    return render_template('config_puerta.html', door_time=door_time)

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = usuarios.find_one({'username': username})
        
        if user and check_password_hash(user['password'], password):
            session['username'] = username  
            return redirect(url_for('index')) 
        else:
            error = "Usuario o contraseña incorrectos."
    
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('username', None)  
    return redirect(url_for('login'))  

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
