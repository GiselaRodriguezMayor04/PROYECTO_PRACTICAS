from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import check_password_hash
from conexion import dbConnection
import time
import RPi.GPIO as GPIO

# Definir los pines de los relés (vinculando dispositivos con los pines)
relays = {
    'door': 26,  # Relé 1
    'luz_principal': 6,  # Relé 2
    'oficina_ventana': 4,  # Relé 3
    'oficina_escalera': 22  # Relé 4
}

# Configuración de GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
for pin in relays.values():
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, GPIO.LOW)  # Inicialmente apagados

# Tiempo que tarda el botón en activarse
door_time = 5
luz_principal_time = 5
oficina_ventana_time = 5
oficina_escalera_time = 5

app = Flask(__name__)
app.secret_key = "tu_clave_secreta"

# Conexión a la base de datos
db = dbConnection()

if db is None:
    print("Error al conectar con la BD")
    exit()

usuarios = db['USUARIOS']

@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('index.html', door_time=door_time, 
                           luz_principal_time=luz_principal_time, 
                           oficina_ventana_time=oficina_ventana_time,
                           oficina_escalera_time=oficina_escalera_time)

@app.route('/activate/<device>')
def activate_device(device):
    global door_time, luz_principal_time, oficina_ventana_time, oficina_escalera_time

    # Solo aceptamos dispositivos válidos
    if device not in relays:
        return jsonify({'status': 'error', 'message': 'Dispositivo no válido'})

    # Activar el relé (GPIO HIGH)
    GPIO.output(relays[device], GPIO.HIGH)
    print(f"{device} RELÉ ACTIVADO")

    # Si es la puerta, lo controlamos manualmente
    if device == 'door':
        return jsonify({'status': 'ok', 'manual': True})

    # Si no es la puerta, calculamos el tiempo
    tiempos = {
        'luz_principal': luz_principal_time,
        'oficina_ventana': oficina_ventana_time,
        'oficina_escalera': oficina_escalera_time
    }
    tiempo_activado = tiempos[device]

    # Lanzamos hilo para apagar automáticamente después de X segundos
    def apagar_rele():
        time.sleep(tiempo_activado)
        GPIO.output(relays[device], GPIO.LOW)
        print(f"{device} RELÉ DESACTIVADO")

    threading.Thread(target=apagar_rele).start()

    return jsonify({'status': 'ok', 'manual': False, 'duration': tiempo_activado})


@app.route('/config_puerta', methods=['GET', 'POST'])
def config_puerta():
    global door_time
    if request.method == 'POST':
        door_time = int(request.form['door_time'])
        return redirect(url_for('index'))
    return render_template('config_puerta.html', door_time=door_time)

@app.route('/config_luz/<device>', methods=['GET', 'POST'])
def config_luz(device):
    global luz_principal_time, oficina_ventana_time, oficina_escalera_time
    
    # Determinamos cuál dispositivo se está configurando
    if device == 'luz_principal':
        current_time = luz_principal_time
    elif device == 'oficina_ventana':
        current_time = oficina_ventana_time
    elif device == 'oficina_escalera':
        current_time = oficina_escalera_time
    else:
        return redirect(url_for('index'))
    
    # Guardamos el nuevo tiempo si es un POST
    if request.method == 'POST':
        new_time = int(request.form['door_time'])
        if device == 'luz_principal':
            luz_principal_time = new_time
        elif device == 'oficina_ventana':
            oficina_ventana_time = new_time
        elif device == 'oficina_escalera':
            oficina_escalera_time = new_time
        return redirect(url_for('index'))
    
    return render_template('config_luz.html', door_time=current_time, device=device)

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = usuarios.find_one({'username': username})

        if user and check_password_hash(user['password'], password):
            session['username'] = username
            return redirect(url_for('index'))
        else:
            error = "Usuario o contraseña incorrectos."

    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
