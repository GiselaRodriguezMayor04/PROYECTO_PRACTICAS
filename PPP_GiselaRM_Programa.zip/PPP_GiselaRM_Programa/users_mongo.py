# user_mongo.py sirve para guardar los usuarios en la BD para hacer el login, es lo primero que se debe ejecutar para poder iniciar el programa.
from werkzeug.security import generate_password_hash
from conexion_bd import dbConnection

db = dbConnection()

if db is None:
    print("No se pudo conectar con la base de datos. Vuelve a intentarlo más tarde.")
    exit()

usuarios = db['USUARIOS']

usuarios.insert_one({
    'username': 'admin',
    'password': generate_password_hash('admin2025'),
    'role': 'admin'
})

usuarios.insert_one({
    'username': 'user',
    'password': generate_password_hash('user2025'),
    'role': 'user'
})

print("Usuarios creados correctamente! :)")
