# Esta clase es para guardar los datos en la BD.
class Vehiculo:
    def __init__(self, matricula, marca, modelo, fecha_inspeccion, estado_frenos, estado):
        self.matricula = matricula
        self.marca = marca
        self.modelo = modelo
        self.fecha_inspeccion = fecha_inspeccion
        self.estado_frenos = estado_frenos
        self.estado = estado

    def toDBCollection(self):
        return {
            'matricula': self.matricula,
            'marca': self.marca,
            'modelo': self.modelo,
            'fecha_inspeccion': self.fecha_inspeccion,
            'estado_frenos': self.estado_frenos,
            'estado': self.estado
        }
