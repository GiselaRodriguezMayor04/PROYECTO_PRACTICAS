from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import conexion_bd as dbase
from Vehiculo import Vehiculo
from bson.objectid import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash

db = dbase.dbConnection()

app = Flask(__name__)
app.secret_key = 'secret_key'

# HOME - TE MANDA AL INDEX SI HAS INTRODUCIDO EL LOGIN CORRECTAMENTE


@app.route('/')
def home():
    if 'user' in session:
        vehiculos = db['VEHICULOS']
        vehiculosReceived = vehiculos.find()
        return render_template('index.html', vehiculos=vehiculosReceived)
    else:
        return redirect(url_for('login'))

# LOGIN - SE ENCARGA DE MIRAR SI ENTRA EL USUARIO CORRECTO Y SABER CUÁL ES, SI ES ADMIN, TIENE PRIVILEGIOS DE ADMINISTRADOR, SI NO, ES UN USUARIO NORMAL (lo puse principalmente para tener variedad y probar con los permisos)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        usuarios = db['USUARIOS']
        user = usuarios.find_one({'username': username})

        if user and check_password_hash(user['password'], password):
            session['user'] = username
            session['role'] = user['role']
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error="Credenciales incorrectas")

    return render_template('login.html')

# VEHICULOS - GUARDA LOS DATOS QUE POSTERIORMENTE VAMOS A INSERTAR


@app.route('/vehiculos', methods=['POST'])
def addVehiculo():
    vehiculos = db['VEHICULOS']
    matricula = request.form['matricula']
    marca = request.form['marca']
    modelo = request.form['modelo']
    fecha_inspeccion = request.form['fecha_inspeccion']
    estado_frenos = request.form['estado_frenos']
    estado = request.form['estado']

    if not estado_frenos or not estado:
        return notFound()

    if matricula and marca and modelo and fecha_inspeccion:
        vehiculo = Vehiculo(matricula, marca, modelo,
                            fecha_inspeccion, estado_frenos, estado)
        vehiculos.insert_one(vehiculo.toDBCollection())
        return redirect(url_for('home'))
    else:
        return notFound()

# DELETE - ELIMINAR LOS DATOS, SE HACE MEDIANTE UN BOTÓN DE ELIMINAR


@app.route('/delete/<string:matricula_vehiculo>')
def delete(matricula_vehiculo):
    if 'user' not in session or session['role'] != 'admin':
        return redirect(url_for('home'))

    vehiculos = db['VEHICULOS']
    vehiculos.delete_one({'matricula': matricula_vehiculo})
    return redirect(url_for('home'))

# EDIT - EDITAR LOS DATOS, SE TIENEN QUE HACER DIRECTAMENTE EN EL APARTADO DONDE SALE LA LISTA DE LOS VEHÍCULOS


# EDIT - FORMULARIO PARA EDITAR VEHÍCULO
@app.route('/edit/<string:matricula_vehiculo>', methods=['GET', 'POST'])
def edit(matricula_vehiculo):
    if 'user' not in session or session['role'] != 'admin':
        return redirect(url_for('home'))

    vehiculos = db['VEHICULOS']
    vehiculo = vehiculos.find_one({'matricula': matricula_vehiculo})

    if request.method == 'POST':
        matricula = request.form['matricula']
        marca = request.form['marca']
        modelo = request.form['modelo']
        fecha_inspeccion = request.form['fecha_inspeccion']
        estado_frenos = request.form['estado_frenos']
        estado = request.form['estado']

        if not estado_frenos or not estado:
            return notFound()

        if matricula and marca and modelo and fecha_inspeccion:
            vehiculos.update_one(
                {'matricula': matricula_vehiculo},
                {'$set': {
                    'matricula': matricula,
                    'marca': marca,
                    'modelo': modelo,
                    'fecha_inspeccion': fecha_inspeccion,
                    'estado_frenos': estado_frenos,
                    'estado': estado
                }}
            )
            return redirect(url_for('home'))
        else:
            return notFound()
        
    return render_template('editar.html', vehiculo=vehiculo)


# BUSCAR - ESTE ES EL APARTADO DE BUSCAR, SE BUSCA POR LA MATRÍCULA DEL COCHE


@app.route('/buscar', methods=['POST'])
def buscar_por_id():
    vehiculos = db['VEHICULOS']

    if 'matricula_id' not in request.form:
        return notFound()

    matricula_id = request.form['matricula_id']

    try:
        vehiculo = vehiculos.find_one({'matricula': matricula_id})

        if vehiculo:
            return render_template('buscar.html', vehiculo=vehiculo)
        else:
            return notFound()

    except Exception as e:
        return notFound()


# LOGOUT - EN CASO DE NO ESTAR LOGUEADO, TE MANDA A LA PÁGINA DE LOGIN
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# CONTROL DE ERRORES, TE MANDA A ESTA PÁGINA SI HAY ALGÚN ERROR


@app.errorhandler(404)
def notFound(error=None):
    message = {
        'message': 'No encontrado ' + request.url,
        'status': '404 Not Found'
    }
    response = jsonify(message)
    response.status_code = 404
    return response


if __name__ == '__main__':
    app.run(debug=True, port=4000)
